#!/bin/bash
yum install java -y
yum install wget -y
yum install tomcat7 -y
