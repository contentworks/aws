from flask import Flask
application = Flask(__name__)

@application.route("/")
def hello():
    return  """<html>
               <head><title>My first Python CGI app</title></head>
                <body>
                <a href="https://cloudthat.in" target="_blank">
                    <img src="https://s3.ap-south-1.amazonaws.com/files.cloudthat.com/aws-developer-latest/ct-logo-small-app.jpg" style="height:100px" />
                </a>
                <p><b>Hello from BeanStalk</b></p>
                </body>
               </html>"""

if __name__ == '__main__':
    application.run()